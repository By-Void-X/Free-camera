#include "freecam_debug.h"

#include <link.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <thread>

#ifdef __ANDROID__
#include <android/log.h>
#endif

namespace freecam_debug {
namespace {

// Offset (virtual address) di libFreecam.so, hasil bedah disassembly.
constexpr uintptr_t kActive = 0x1aca9;     // byte: freecam aktif
constexpr uintptr_t kValid = 0x1acab;      // byte: kamera sudah ter-capture
constexpr uintptr_t kPlayer = 0x1acb0;     // pointer: local player
constexpr uintptr_t kInput = 0x1acb8;      // float[3]: input (-x, -z/maju, vertikal)
constexpr uintptr_t kSprint = 0x1acc4;     // byte: sprint
constexpr uintptr_t kSpeed = 0x1acc8;      // float: fly speed
constexpr uintptr_t kSprintMul = 0x1accc;  // float
constexpr uintptr_t kSmooth = 0x1acd0;     // float
constexpr uintptr_t kLockRot = 0x1acd4;    // byte
constexpr uintptr_t kSeeThrough = 0x1acd5; // byte
constexpr uintptr_t kFixTerrain = 0x1acd6; // byte
constexpr uintptr_t kBlockPackets = 0x1acd7; // byte
constexpr uintptr_t kCamPos = 0x1acd8;     // float[3]: posisi kamera
constexpr uintptr_t kVelocity = 0x1ace4;   // float[3]: kecepatan (smoothed)
// Penanda untuk memastikan ini build libFreecam yang benar.
constexpr uintptr_t kSigAddr1 = 0x8f24;
constexpr uint32_t kSigVal1 = 0x1e3e1002;
constexpr uintptr_t kSigAddr2 = 0x8f28;
constexpr uint32_t kSigVal2 = 0x7100015f;

constexpr long kMaxFileBytes = 3 * 1024 * 1024;

std::atomic<bool> gRun{false};
std::thread gThread;
FILE* gFile = nullptr;
long gBytes = 0;
std::chrono::steady_clock::time_point gT0;

void out(const char* fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                  std::chrono::steady_clock::now() - gT0).count();
    char line[640];
    int n = snprintf(line, sizeof(line), "[%lld.%03lld] %s\n",
                     (long long)(ms / 1000), (long long)(ms % 1000), buf);
#ifdef __ANDROID__
    __android_log_print(ANDROID_LOG_INFO, "FreecamDebug", "%s", line);
#endif
    if (gFile && gBytes < kMaxFileBytes && n > 0) {
        fputs(line, gFile);
        fflush(gFile);
        gBytes += n;
    }
}

std::string packageName() {
    FILE* f = fopen("/proc/self/cmdline", "r");
    if (!f) return {};
    char b[256] = {0};
    size_t r = fread(b, 1, sizeof(b) - 1, f);
    fclose(f);
    b[r] = 0;
    return std::string(b);
}

void openFile() {
    std::string pkg = packageName();
    std::string cands[] = {
        "/storage/emulated/0/Download/freecam-debug.log",
        "/sdcard/Download/freecam-debug.log",
        pkg.empty() ? std::string() : "/storage/emulated/0/Android/data/" + pkg + "/files/freecam-debug.log",
    };
    for (auto& p : cands) {
        if (p.empty()) continue;
        gFile = fopen(p.c_str(), "w");
        if (gFile) {
#ifdef __ANDROID__
            __android_log_print(ANDROID_LOG_INFO, "FreecamDebug", "log file: %s", p.c_str());
#endif
            return;
        }
    }
}

int phdrCb(dl_phdr_info* info, size_t, void* data) {
    if (info->dlpi_name && std::strstr(info->dlpi_name, "libFreecam.so")) {
        *static_cast<uintptr_t*>(data) = static_cast<uintptr_t>(info->dlpi_addr);
        return 1;
    }
    return 0;
}

uintptr_t findBase() {
    uintptr_t base = 0;
    dl_iterate_phdr(phdrCb, &base);
    return base;
}

template <typename T>
T rd(uintptr_t base, uintptr_t off) {
    T v{};
    std::memcpy(&v, reinterpret_cast<const void*>(base + off), sizeof(T));
    return v;
}

struct Snap {
    uint8_t active, valid, sprint;
    uint64_t player;
    float in[3];
    float cam[3];
    float vel[3];
};

Snap take(uintptr_t b) {
    Snap s{};
    s.active = rd<uint8_t>(b, kActive);
    s.valid = rd<uint8_t>(b, kValid);
    s.sprint = rd<uint8_t>(b, kSprint);
    s.player = rd<uint64_t>(b, kPlayer);
    for (int i = 0; i < 3; i++) {
        s.in[i] = rd<float>(b, kInput + 4 * i);
        s.cam[i] = rd<float>(b, kCamPos + 4 * i);
        s.vel[i] = rd<float>(b, kVelocity + 4 * i);
    }
    return s;
}

int sgn(float v) { return v > 0.01f ? 1 : (v < -0.01f ? -1 : 0); }

void loop() {
    uintptr_t base = 0;
    Snap prev{};
    bool havePrev = false;
    auto lastBeat = std::chrono::steady_clock::now();
    uintptr_t lastBase = 0;

    while (gRun.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
        base = findBase();
        if (!base) {
            if (lastBase) out("libFreecam.so tidak lagi ter-load");
            lastBase = 0;
            havePrev = false;
            continue;
        }
        if (base != lastBase) {
            lastBase = base;
            bool ok = rd<uint32_t>(base, kSigAddr1) == kSigVal1 &&
                      rd<uint32_t>(base, kSigAddr2) == kSigVal2;
            out("libFreecam.so ter-load, base=0x%llx, build %s", (unsigned long long)base,
                ok ? "DIKENAL" : "TIDAK DIKENAL (offset bisa salah, log tidak valid)");
            if (!ok) { gRun = false; break; }
            out("settings: speed=%.2f sprintMul=%.2f smooth=%.2f lockRot=%u seeThrough=%u fixTerrain=%u blockPackets=%u",
                rd<float>(base, kSpeed), rd<float>(base, kSprintMul), rd<float>(base, kSmooth),
                rd<uint8_t>(base, kLockRot), rd<uint8_t>(base, kSeeThrough),
                rd<uint8_t>(base, kFixTerrain), rd<uint8_t>(base, kBlockPackets));
        }

        Snap s = take(base);
        bool changed = !havePrev || s.active != prev.active || s.valid != prev.valid ||
                       s.sprint != prev.sprint || (s.player != 0) != (prev.player != 0) ||
                       sgn(s.in[0]) != sgn(prev.in[0]) || sgn(s.in[1]) != sgn(prev.in[1]) ||
                       sgn(s.in[2]) != sgn(prev.in[2]);
        auto now = std::chrono::steady_clock::now();
        bool beat = s.active && now - lastBeat > std::chrono::milliseconds(500);

        if (changed || beat) {
            lastBeat = now;
            float dy = havePrev ? s.cam[1] - prev.cam[1] : 0.f;
            out("%s active=%u valid=%u player=%s input(x=%.2f z=%.2f VERT=%.2f) sprint=%u "
                "cam=(%.2f,%.2f,%.2f) vel=(%.2f,%.2f,%.2f) dY=%+.3f",
                changed ? "CHG " : "BEAT", s.active, s.valid, s.player ? "ada" : "null",
                s.in[0], s.in[1], s.in[2], s.sprint, s.cam[0], s.cam[1], s.cam[2],
                s.vel[0], s.vel[1], s.vel[2], dy);
        }
        prev = s;
        havePrev = true;
    }
}

} // namespace

void start() {
    if (gRun.exchange(true)) return;
    gT0 = std::chrono::steady_clock::now();
    openFile();
    out("FreecamDebug start (file=%s)", gFile ? "ok" : "TIDAK BISA DIBUAT, hanya logcat");
    gThread = std::thread(loop);
}

void stop() {
    if (!gRun.exchange(false) && !gThread.joinable()) return;
    if (gThread.joinable()) gThread.join();
    out("FreecamDebug stop");
    if (gFile) {
        fclose(gFile);
        gFile = nullptr;
    }
    gBytes = 0;
}

} // namespace freecam_debug
