#include <pl/Mod.hpp>
#include <pl/ModMenu.hpp>

#include "freecam_debug.h"

#include <string_view>

namespace freecam_vertical_controls {

namespace {
constexpr std::string_view kModuleId = "freecam_vertical_controls.controls";
constexpr std::string_view kUpButtonId = "freecam_vertical_controls.up";
constexpr std::string_view kDownButtonId = "freecam_vertical_controls.down";
// Android key codes: KEYCODE_SPACE = 62, KEYCODE_SHIFT_LEFT = 59.
// The buttons forward these keys while held; Freecam must already be enabled.
constexpr int kJumpKeyCode = 62;
constexpr int kSneakKeyCode = 59;
}

class FreecamVerticalControls {
public:
    static FreecamVerticalControls& instance() {
        static FreecamVerticalControls instance;
        return instance;
    }

    FreecamVerticalControls() : mSelf(*ll::mod::NativeMod::current()) {}
    [[nodiscard]] ll::mod::NativeMod& getSelf() const { return mSelf; }

    bool load() {
        getSelf().getLogger().info("Freecam Vertical Controls loaded");
        return true;
    }

    bool enable() {
        auto& logger = getSelf().getLogger();
        const bool moduleOk = pl::modmenu::ModuleBuilder(
                                  std::string(kModuleId), "Freecam Vertical Controls")
                                  .modId(getSelf().getId())
                                  .description("Adds hold buttons for jump/up and sneak/down. Intended to use with Freecam.")
                                  .defaultEnabled(true)
                                  .registerModule();

        const bool upOk = pl::modmenu::ButtonBuilder(std::string(kUpButtonId), "Freecam Up")
                              .modId(getSelf().getId())
                              .moduleId(std::string(kModuleId))
                              .label("↑")
                              .androidKeyCode(kJumpKeyCode)
                              .behavior(pl::modmenu::ButtonBehavior::Hold)
                              .registerButton();

        const bool downOk = pl::modmenu::ButtonBuilder(std::string(kDownButtonId), "Freecam Down")
                                .modId(getSelf().getId())
                                .moduleId(std::string(kModuleId))
                                .label("↓")
                                .androidKeyCode(kSneakKeyCode)
                                .behavior(pl::modmenu::ButtonBehavior::Hold)
                                .registerButton();

        logger.info("UI registration: module={}, up={}, down={}", moduleOk, upOk, downOk);
        freecam_debug::start();
        return moduleOk && upOk && downOk;
    }

    bool disable() {
        freecam_debug::stop();
        pl::modmenu::unregisterButton(kUpButtonId);
        pl::modmenu::unregisterButton(kDownButtonId);
        pl::modmenu::unregisterModule(kModuleId);
        return true;
    }

    bool unload() { return true; }

private:
    ll::mod::NativeMod& mSelf;
};

} // namespace freecam_vertical_controls

PL_REGISTER_MOD(freecam_vertical_controls::FreecamVerticalControls,
                freecam_vertical_controls::FreecamVerticalControls::instance());
