#pragma once

// Logger diagnostik read-only untuk libFreecam.so (build v1.0 / manifest 2.1.0).
// Membaca variabel global Freecam lewat offset tetap dan menulis log ke:
//   - logcat (tag "FreecamDebug")
//   - file freecam-debug.log (Download, atau folder Android/data aplikasi)
namespace freecam_debug {
void start();
void stop();
} // namespace freecam_debug
