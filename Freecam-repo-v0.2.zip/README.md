# Freecam Vertical Controls (LeviLaunchroid)

A small native LeviLaunchroid helper mod that registers two floating **hold** buttons:

- `↑` sends Android `KEYCODE_SPACE` (62), normally used as jump/up.
- `↓` sends Android `KEYCODE_SHIFT_LEFT` (59), normally used as sneak/down.

It is intended to be enabled alongside the existing Freecam mod. It does **not** replace or patch the original `libFreecam.so`.

## Important limitation

This is a compatibility prototype, not a confirmed fix. Whether the existing Freecam responds to injected key codes depends on how the launcher dispatches button key events and how that Freecam build reads input. The project cannot guarantee vertical camera movement until tested in Minecraft 1.26.52. If the buttons appear but the camera does not move, the original Freecam's camera/input logic will need a version-specific hook or source-level patch.

## Build on GitHub (phone-friendly)

1. Create a new empty GitHub repository.
2. Upload the contents of this ZIP to the repository root (not the enclosing folder).
3. Open **Actions** and enable workflows if GitHub asks.
4. Run **Build LeviPack** from the Actions tab, or push a commit.
5. Open the completed workflow run and download the `Freecam-Vertical-Controls-levipack` artifact.
6. Import the `.levipack` into LeviLaunchroid, then enable both this helper and the original Freecam.

The workflow uses the official Preloader Android SDK and builds an ARM64 package. It does not require building on the phone.

## Source

- LeviLaunchroid mod template: https://github.com/QYCottage/levilauncher-android-mod-template
- Mod API: https://docs.levimc.org/LeviLaunchroid/api/mod
- Mod Menu API: https://docs.levimc.org/LeviLaunchroid/api/mod-menu

## Folder `original-freecam/`

Hasil ekstrak `Levi-Freecam-v1_0.levipack` (mod buatan GamingPrince76, bukan milik repo ini):

- `manifest.json`
- `libFreecam.so` (hasil kompilasi, bukan source)

Disimpan hanya sebagai referensi/bahan analisis. Kalau repo ini dipublikasikan, minta izin pembuatnya atau hapus folder ini dan beri kredit ke repo aslinya: https://github.com/GamingPrince76/Levi-Freecam

Untuk membungkus ulang jadi `.levipack` (manifest di root, tanpa subfolder):

```bash
cd original-freecam && zip -r ../Freecam-repack.levipack manifest.json libFreecam.so
```


## v0.2.0: fitur log diagnostik

Mod ini sekarang punya logger read-only untuk `libFreecam.so` (build yang di `original-freecam/`).
Logger membaca variabel global Freecam (input naik/turun, posisi kamera, kecepatan) dan menulis:

- logcat, tag `FreecamDebug`
- file `Download/freecam-debug.log` (kalau Download tidak bisa ditulis, dicoba `Android/data/<paket>/files/`)

Cara pakai:

1. Import `.levipack` ini, aktifkan **bersama** Freecam.
2. Masuk world, aktifkan Freecam, lalu tes turun (tombol ↓ hold dan tombol jongkok bawaan).
3. Kirim isi `freecam-debug.log`.

Cara baca baris log: `VERT` = input vertikal (+1 naik, -1 turun, 0 diam), `dY` = perubahan tinggi kamera
sejak log sebelumnya. Kalau `VERT=-1.00` tapi `dY` hampir 0, berarti kamera tertahan di sisi Freecam.
Kalau `VERT` cepat kembali ke 0 padahal tombol masih ditekan, input jongkoknya yang hilang.

Kalau log menulis `build TIDAK DIKENAL`, `libFreecam.so` yang aktif bukan build v1.0 dan logger berhenti sendiri.

Manifest dan layout paket disamakan dengan `.levipack` Freecam asli (manifest.json + .so di root).
